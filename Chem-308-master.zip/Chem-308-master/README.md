# Chem-308

### Table of Contents

1. [Summary of Key Quantum Ideas](/Background.md)
1. [Particle in a Box - 1D](/PIBfix.md)
    - [Eigsort Function](/Eigsort.md)

